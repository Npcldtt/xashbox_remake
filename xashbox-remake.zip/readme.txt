Xashbox Remake
Version 1.0
Created on 17 August 2023
Acually this is in developement

How to Setup
1 Extract this archive 
2 Move Xashbox and menufolder To Valve
3 Launch Half life
4 Go to configuration and Touch And Touch button
5 Add the Button
6 Change touch command like this: exec menufolder/xashboxremake
7 Save
And done Have fun!

How to fix Coop mode not working
1 Go to the archive
2 Go to folder named Apks
3 Open it
4 Download it
5 Launch it and click Launch GumMod!
And done Have fun!
